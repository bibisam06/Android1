package com.hanbi.movie.model

class ItemModel {
    var adult : String ? =null
    var title : String ? = null
    var release_date : String ? = null
    var poster_path : String ? = null
    var vote_average : String ? = null
}