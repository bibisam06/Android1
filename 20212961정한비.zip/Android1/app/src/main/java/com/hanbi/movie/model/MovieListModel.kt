package com.hanbi.movie.model

class MovieListModel {
    var results: MutableList<ItemModel> ?= null
}